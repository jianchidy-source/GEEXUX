// Paste your own values from Supabase: Project Settings > API
const SUPABASE_URL = "PASTE_PROJECT_URL_HERE";
const SUPABASE_ANON_KEY = "PASTE_ANON_PUBLIC_KEY_HERE";
