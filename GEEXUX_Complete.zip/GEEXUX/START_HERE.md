# GEEXUX — start here

Everything is in this one zip. Unzip it first.

## What's inside
- `1_database/1_NEW_SETUP_schema.sql` — the full database setup (use this for a first-time install)
- `1_database/ONLY_IF_UPDATING_update.sql` — only for people who installed an older version
- `2_website/` — the website itself. This is the folder you publish.

## Step 1 — Database (about 5 minutes, free)
1. Create a free project at supabase.com.
2. Open **SQL Editor > New query**, paste all of `1_NEW_SETUP_schema.sql`, press **Run**.
3. Open **Project Settings > API**. Copy the **Project URL** and the **anon public** key.
4. Open `2_website/config.js` in any text editor and paste both values in. (Never use the "service_role" key.)
5. **Authentication > Providers > Email**: turn off "Confirm email" while testing; turn it back on for a real launch.

## Step 2 — Publish the website
Drag the **`2_website`** folder onto app.netlify.com/drop (or use Cloudflare Pages / Vercel / GitHub Pages). You get an https link.
Then in Supabase go to **Authentication > URL Configuration** and set **Site URL** to that link.

## Step 3 — Make yourself admin
Sign up on your site, then in the Supabase SQL Editor run (use your own username):
`insert into admins(user_id) select id from profiles where handle='YOURUSERNAME';`
A **Reports** tab appears for you, where you can dismiss reports or remove posts.

## Step 4 — Legal pages
Open `2_website/terms.html` and `2_website/privacy.html`, fill in everything in [BRACKETS], and have a lawyer in your country review them.

## What the app does
Sign-up and login with country and flag, shared posts, likes, comments, follows (For you / Following), private accounts with follow requests, direct messages, photo and video editing (filters, rotate, text, trim), songs on posts, hashtags and trending, people search and public profiles, Explore by country, notifications, translate button, blocking, reporting, admin review, account deletion, and an installable app icon (airplane).

## Notes
- Uploaded photos, videos and songs are stored in Supabase Storage (max 20 MB per post file, 10 MB per song). Deleting an account removes database records but not those files.
- Check Supabase's and your host's current free-plan limits before a big launch.
