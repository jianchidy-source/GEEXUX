-- Run this ONCE in Supabase SQL Editor if you already ran the earlier schema.sql
alter table posts add column if not exists filter text, add column if not exists trim_start numeric, add column if not exists trim_end numeric, add column if not exists audio_url text, add column if not exists audio_name text, add column if not exists mute_orig boolean default false;
update storage.buckets set allowed_mime_types=array['image/jpeg','image/png','image/webp','image/gif','video/mp4','video/webm','video/quicktime','audio/mpeg','audio/mp3','audio/mp4','audio/x-m4a','audio/aac','audio/wav','audio/x-wav','audio/ogg','audio/webm'] where id='media';

-- World features: country on profiles (safe to re-run)
alter table profiles add column if not exists country text;
create or replace function handle_new_user() returns trigger language plpgsql security definer set search_path=public as $$
begin insert into profiles(id,handle,name,country) values(new.id,lower(regexp_replace(coalesce(new.raw_user_meta_data->>'handle','user'||substr(new.id::text,1,6)),'[^a-zA-Z0-9_.]','','g')),coalesce(nullif(new.raw_user_meta_data->>'name',''),'GEEXUX User'),nullif(upper(left(new.raw_user_meta_data->>'country',2)),''));return new;end $$;

-- ===== Safety & privacy: blocking, private accounts, reports review, account deletion (safe to re-run) =====
alter table profiles add column if not exists is_private boolean default false;
alter table follows add column if not exists status text default 'accepted';
alter table reports add column if not exists reason text;
create table if not exists blocks(blocker uuid references profiles(id) on delete cascade,blocked uuid references profiles(id) on delete cascade,primary key(blocker,blocked));
create table if not exists admins(user_id uuid primary key references profiles(id) on delete cascade);
alter table blocks enable row level security;alter table admins enable row level security;
create or replace function is_blocked(a uuid,b uuid) returns boolean language sql security definer stable set search_path=public as $$ select exists(select 1 from blocks where (blocker=a and blocked=b) or (blocker=b and blocked=a)) $$;
create or replace function is_admin() returns boolean language sql security definer stable set search_path=public as $$ select exists(select 1 from admins where user_id=auth.uid()) $$;
create or replace function can_see(author uuid) returns boolean language sql security definer stable set search_path=public as $$ select author=auth.uid() or (not is_blocked(auth.uid(),author) and (not coalesce((select is_private from profiles where id=author),false) or exists(select 1 from follows f where f.follower=auth.uid() and f.followed=author and f.status='accepted'))) $$;
drop policy if exists "read posts" on posts;create policy "read posts" on posts for select to authenticated using(can_see(user_id));
drop policy if exists "admin delete posts" on posts;create policy "admin delete posts" on posts for delete to authenticated using(is_admin());
drop policy if exists "read likes" on likes;create policy "read likes" on likes for select to authenticated using(exists(select 1 from posts p where p.id=post_id));
drop policy if exists "read comments" on comments;create policy "read comments" on comments for select to authenticated using(exists(select 1 from posts p where p.id=post_id));
drop policy if exists "add own like" on likes;create policy "add own like" on likes for insert to authenticated with check(user_id=auth.uid() and exists(select 1 from posts p where p.id=post_id));
drop policy if exists "add own comment" on comments;create policy "add own comment" on comments for insert to authenticated with check(user_id=auth.uid() and exists(select 1 from posts p where p.id=post_id));
drop policy if exists "send message" on messages;create policy "send message" on messages for insert to authenticated with check(sender=auth.uid() and not is_blocked(sender,recipient));
drop policy if exists "read own blocks" on blocks;create policy "read own blocks" on blocks for select to authenticated using(blocker=auth.uid());
drop policy if exists "block" on blocks;create policy "block" on blocks for insert to authenticated with check(blocker=auth.uid());
drop policy if exists "unblock" on blocks;create policy "unblock" on blocks for delete to authenticated using(blocker=auth.uid());
drop policy if exists "read own admin row" on admins;create policy "read own admin row" on admins for select to authenticated using(user_id=auth.uid());
drop policy if exists "admins read reports" on reports;create policy "admins read reports" on reports for select to authenticated using(is_admin());
drop policy if exists "admins delete reports" on reports;create policy "admins delete reports" on reports for delete to authenticated using(is_admin());
create or replace function set_follow_status() returns trigger language plpgsql security definer set search_path=public as $$ begin if is_blocked(new.follower,new.followed) then raise exception 'not allowed'; end if; new.status:=case when coalesce((select is_private from profiles where id=new.followed),false) then 'pending' else 'accepted' end; return new; end $$;
drop trigger if exists follow_status on follows;create trigger follow_status before insert on follows for each row execute function set_follow_status();
drop policy if exists "unfollow" on follows;drop policy if exists "unfollow or remove" on follows;create policy "unfollow or remove" on follows for delete to authenticated using(follower=auth.uid() or followed=auth.uid());
drop policy if exists "approve follower" on follows;create policy "approve follower" on follows for update to authenticated using(followed=auth.uid()) with check(followed=auth.uid());
create or replace function delete_my_account() returns void language sql security definer set search_path=public,auth as $$ delete from auth.users where id=auth.uid() $$;
revoke all on function delete_my_account() from public,anon;grant execute on function delete_my_account() to authenticated;
