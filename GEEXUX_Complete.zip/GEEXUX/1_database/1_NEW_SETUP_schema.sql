-- Run this once in Supabase: SQL Editor > New query > paste > Run
create table profiles(id uuid primary key references auth.users on delete cascade,handle text unique not null,name text not null,bio text default 'Hello from GEEXUX ✨',created_at timestamptz default now());
create table posts(id uuid primary key default gen_random_uuid(),user_id uuid not null references profiles(id) on delete cascade,caption text not null check(char_length(caption)<=500),media_url text,media_type text,created_at timestamptz default now());
create table likes(post_id uuid references posts on delete cascade,user_id uuid references profiles(id) on delete cascade,primary key(post_id,user_id));
create table comments(id uuid primary key default gen_random_uuid(),post_id uuid not null references posts on delete cascade,user_id uuid not null references profiles(id) on delete cascade,text text not null check(char_length(text)<=240),created_at timestamptz default now());
create table follows(follower uuid references profiles(id) on delete cascade,followed uuid references profiles(id) on delete cascade,primary key(follower,followed));
create table messages(id uuid primary key default gen_random_uuid(),sender uuid not null references profiles(id) on delete cascade,recipient uuid not null references profiles(id) on delete cascade,text text not null check(char_length(text)<=1000),created_at timestamptz default now());
create table reports(id uuid primary key default gen_random_uuid(),post_id uuid references posts on delete cascade,user_id uuid references profiles(id),created_at timestamptz default now());
alter table profiles enable row level security;alter table posts enable row level security;alter table likes enable row level security;alter table comments enable row level security;alter table follows enable row level security;alter table messages enable row level security;alter table reports enable row level security;
create policy "read profiles" on profiles for select to authenticated using(true);
create policy "edit own profile" on profiles for update to authenticated using(id=auth.uid());
create policy "read posts" on posts for select to authenticated using(true);
create policy "add own post" on posts for insert to authenticated with check(user_id=auth.uid());
create policy "delete own post" on posts for delete to authenticated using(user_id=auth.uid());
create policy "read likes" on likes for select to authenticated using(true);
create policy "add own like" on likes for insert to authenticated with check(user_id=auth.uid());
create policy "remove own like" on likes for delete to authenticated using(user_id=auth.uid());
create policy "read comments" on comments for select to authenticated using(true);
create policy "add own comment" on comments for insert to authenticated with check(user_id=auth.uid());
create policy "delete own comment" on comments for delete to authenticated using(user_id=auth.uid());
create policy "read own follows" on follows for select to authenticated using(true);
create policy "follow" on follows for insert to authenticated with check(follower=auth.uid());
create policy "unfollow" on follows for delete to authenticated using(follower=auth.uid());
create policy "read my messages" on messages for select to authenticated using(sender=auth.uid() or recipient=auth.uid());
create policy "send message" on messages for insert to authenticated with check(sender=auth.uid());
create policy "report post" on reports for insert to authenticated with check(user_id=auth.uid());
create or replace function handle_new_user() returns trigger language plpgsql security definer set search_path=public as $$
begin insert into profiles(id,handle,name) values(new.id,lower(regexp_replace(coalesce(new.raw_user_meta_data->>'handle','user'||substr(new.id::text,1,6)),'[^a-zA-Z0-9_.]','','g')),coalesce(nullif(new.raw_user_meta_data->>'name',''),'GEEXUX User'));return new;end $$;
create trigger on_auth_user_created after insert on auth.users for each row execute function handle_new_user();
insert into storage.buckets(id,name,public,file_size_limit,allowed_mime_types) values('media','media',true,20971520,array['image/jpeg','image/png','image/webp','image/gif','video/mp4','video/webm','video/quicktime']);
create policy "upload to own folder" on storage.objects for insert to authenticated with check(bucket_id='media' and (storage.foldername(name))[1]=auth.uid()::text);
create policy "delete own media" on storage.objects for delete to authenticated using(bucket_id='media' and (storage.foldername(name))[1]=auth.uid()::text);
alter publication supabase_realtime add table posts,likes,comments,messages;

-- Editing & songs (added later)
alter table posts add column if not exists filter text, add column if not exists trim_start numeric, add column if not exists trim_end numeric, add column if not exists audio_url text, add column if not exists audio_name text, add column if not exists mute_orig boolean default false;
update storage.buckets set allowed_mime_types=array['image/jpeg','image/png','image/webp','image/gif','video/mp4','video/webm','video/quicktime','audio/mpeg','audio/mp3','audio/mp4','audio/x-m4a','audio/aac','audio/wav','audio/x-wav','audio/ogg','audio/webm'] where id='media';

-- World features: country on profiles (safe to re-run)
alter table profiles add column if not exists country text;
create or replace function handle_new_user() returns trigger language plpgsql security definer set search_path=public as $$
begin insert into profiles(id,handle,name,country) values(new.id,lower(regexp_replace(coalesce(new.raw_user_meta_data->>'handle','user'||substr(new.id::text,1,6)),'[^a-zA-Z0-9_.]','','g')),coalesce(nullif(new.raw_user_meta_data->>'name',''),'GEEXUX User'),nullif(upper(left(new.raw_user_meta_data->>'country',2)),''));return new;end $$;

-- ===== Safety & privacy: blocking, private accounts, reports review, account deletion (safe to re-run) =====
alter table profiles add column if not exists is_private boolean default false;
alter table follows add column if not exists status text default 'accepted';
alter table reports add column if not exists reason text;
create table if not exists blocks(blocker uuid references profiles(id) on delete cascade,blocked uuid references profiles(id) on delete cascade,primary key(blocker,blocked));
create table if not exists admins(user_id uuid primary key references profiles(id) on delete cascade);
alter table blocks enable row level security;alter table admins enable row level security;
create or replace function is_blocked(a uuid,b uuid) returns boolean language sql security definer stable set search_path=public as $$ select exists(select 1 from blocks where (blocker=a and blocked=b) or (blocker=b and blocked=a)) $$;
create or replace function is_admin() returns boolean language sql security definer stable set search_path=public as $$ select exists(select 1 from admins where user_id=auth.uid()) $$;
create or replace function can_see(author uuid) returns boolean language sql security definer stable set search_path=public as $$ select author=auth.uid() or (not is_blocked(auth.uid(),author) and (not coalesce((select is_private from profiles where id=author),false) or exists(select 1 from follows f where f.follower=auth.uid() and f.followed=author and f.status='accepted'))) $$;
drop policy if exists "read posts" on posts;create policy "read posts" on posts for select to authenticated using(can_see(user_id));
drop policy if exists "admin delete posts" on posts;create policy "admin delete posts" on posts for delete to authenticated using(is_admin());
drop policy if exists "read likes" on likes;create policy "read likes" on likes for select to authenticated using(exists(select 1 from posts p where p.id=post_id));
drop policy if exists "read comments" on comments;create policy "read comments" on comments for select to authenticated using(exists(select 1 from posts p where p.id=post_id));
drop policy if exists "add own like" on likes;create policy "add own like" on likes for insert to authenticated with check(user_id=auth.uid() and exists(select 1 from posts p where p.id=post_id));
drop policy if exists "add own comment" on comments;create policy "add own comment" on comments for insert to authenticated with check(user_id=auth.uid() and exists(select 1 from posts p where p.id=post_id));
drop policy if exists "send message" on messages;create policy "send message" on messages for insert to authenticated with check(sender=auth.uid() and not is_blocked(sender,recipient));
drop policy if exists "read own blocks" on blocks;create policy "read own blocks" on blocks for select to authenticated using(blocker=auth.uid());
drop policy if exists "block" on blocks;create policy "block" on blocks for insert to authenticated with check(blocker=auth.uid());
drop policy if exists "unblock" on blocks;create policy "unblock" on blocks for delete to authenticated using(blocker=auth.uid());
drop policy if exists "read own admin row" on admins;create policy "read own admin row" on admins for select to authenticated using(user_id=auth.uid());
drop policy if exists "admins read reports" on reports;create policy "admins read reports" on reports for select to authenticated using(is_admin());
drop policy if exists "admins delete reports" on reports;create policy "admins delete reports" on reports for delete to authenticated using(is_admin());
create or replace function set_follow_status() returns trigger language plpgsql security definer set search_path=public as $$ begin if is_blocked(new.follower,new.followed) then raise exception 'not allowed'; end if; new.status:=case when coalesce((select is_private from profiles where id=new.followed),false) then 'pending' else 'accepted' end; return new; end $$;
drop trigger if exists follow_status on follows;create trigger follow_status before insert on follows for each row execute function set_follow_status();
drop policy if exists "unfollow" on follows;drop policy if exists "unfollow or remove" on follows;create policy "unfollow or remove" on follows for delete to authenticated using(follower=auth.uid() or followed=auth.uid());
drop policy if exists "approve follower" on follows;create policy "approve follower" on follows for update to authenticated using(followed=auth.uid()) with check(followed=auth.uid());
create or replace function delete_my_account() returns void language sql security definer set search_path=public,auth as $$ delete from auth.users where id=auth.uid() $$;
revoke all on function delete_my_account() from public,anon;grant execute on function delete_my_account() to authenticated;
