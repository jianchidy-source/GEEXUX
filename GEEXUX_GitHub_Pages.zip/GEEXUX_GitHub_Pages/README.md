# GEEXUX — Movies & Anime

GEEXUX is a movie and anime discovery website with search, genre filters, My List, and a demo GEEXUX AI recommendation feature.

## GitHub Pages

Upload the files in this folder to the root of the repository, especially `index.html`. Then enable GitHub Pages from Settings → Pages → Deploy from branch → `main` → `/ (root)`.

Actual viewing should use licensed or authorised streaming sources.
