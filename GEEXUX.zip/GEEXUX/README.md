# GEEXUX — Movies & Anime

A responsive movie/anime discovery website with:
- GEEXUX branding and logo
- Real movie/anime titles in the catalog
- Search and genre filters
- Details modal
- My List saved in localStorage
- Demo recommendation assistant
- Mobile-friendly layout

For live metadata, posters, ratings and release information, connect a TMDB API key. TMDB provides movie/TV search, discover, popular and genre endpoints; commercial use has separate licensing requirements.

This demo is a discovery/catalog interface and does not provide pirated streams or unauthorized downloads.
