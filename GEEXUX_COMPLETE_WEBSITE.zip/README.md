# GEEXUX — Complete Website Package

This package combines the GEEXUX project files for the GitHub Pages website.

Included:
- `index.html` — main website
- `geexux-logo.png` or `geexux-logo.svg` — logo if present
- `README.md` — setup notes
- `catalog.txt` — movies/anime discussed in the project

For GitHub Pages, extract this ZIP and put `index.html` in the root of the `main` branch.
Then use Settings → Pages → Deploy from a branch → `main` → `/(root)`.

GEEXUX is a discovery interface; actual viewing should use authorized/licensed providers.
